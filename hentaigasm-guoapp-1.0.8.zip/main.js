// H站精选 模块 · 基于潮流AV模板适配 https://hentaigasm.com
const BASE = "https://hentaigasm.com";

const CATS = [
  { id: "new", name: "最新里番", path: "/hentai/new-hentai-release/" },
  { id: "uncensored", name: "无码", path: "/genre/uncensored/" },
  { id: "3d", name: "3D动画", path: "/genre/3d/" },
  { id: "anal", name: "肛交", path: "/genre/anal/" },
  { id: "blowjob", name: "口交", path: "/genre/blowjob/" },
  { id: "bondage", name: "捆绑", path: "/genre/bondage/" },
  { id: "creampie", name: "中出", path: "/genre/creampie/" },
  { id: "futanari", name: "扶她", path: "/genre/futanari/" },
  { id: "harem", name: "后宫", path: "/genre/harem/" },
  { id: "incest", name: "乱伦", path: "/genre/incest/" },
  { id: "tentacle", name: "触手", path: "/genre/tentacle/" },
  { id: "yuri", name: "百合", path: "/genre/yuri/" },
];

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36";

function baseHeaders(referer) {
  return {
    "User-Agent": UA,
    Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7",
    "Cache-Control": "no-cache",
    Pragma: "no-cache",
    "Upgrade-Insecure-Requests": "1",
    Referer: referer || BASE + "/",
  };
}

function stripTags(s) {
  return String(s == null ? "" : s)
    .replace(/<[^>]*>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function unesc(s) {
  return stripTags(
    String(s == null ? "" : s)
      .replace(/&amp;?/g, "&")
      .replace(/&lt;?/g, "<")
      .replace(/&gt;?/g, ">")
      .replace(/&quot;?/g, '"')
      .replace(/&#0?39;?/g, "'")
      .replace(/&nbsp;?/g, " ")
  );
}

// 轻微清理英文标题：去掉常见后缀，保留原作品名
function cleanTitle(s) {
  let t = unesc(s);
  if (!t) return t;
  t = t
    .replace(/\s*[-–|]\s*(?:New Hentai|Hentaigasm|Episode Video).*$/i, "")
    .replace(/\s*\b(?:Subbed|Uncensored|Censored|HD|FHD|Full)\b\s*$/gi, "")
    .replace(/\s*\b(?:Subbed|Uncensored|Censored)\b/gi, "")
    .replace(/\s{2,}/g, " ")
    .trim();
  return t || unesc(s);
}

function abs(u) {
  const s = String(u == null ? "" : u).trim();
  if (!s) return "";
  if (s.startsWith("//")) return "https:" + s;
  if (/^https?:/i.test(s)) return s;
  if (s.startsWith("/")) return BASE + s;
  return BASE + "/" + s;
}

function getHtml(path, referer) {
  const url = path.startsWith("http") ? path : BASE + (path.charAt(0) === "/" ? path : "/" + path);
  const res = host.fetch({
    url: url,
    method: "GET",
    headers: baseHeaders(referer || BASE + "/"),
    timeoutMs: 18000,
    anyStatus: true,
    followRedirects: true,
    limit: 4 * 1024 * 1024,
  });
  if (!res) throw new Error("无响应");
  if (res.status === 404) throw new Error("页面不存在");
  if (res.status >= 400) throw new Error("HTTP " + res.status);
  const body = String(res.body || "");
  if (!body || body.length < 200) throw new Error("内容为空");
  return body;
}

function findCat(id) {
  for (let i = 0; i < CATS.length; i++) {
    if (CATS[i].id === id) return CATS[i];
  }
  return CATS[0];
}

function listUrl(catId, page) {
  const cat = findCat(catId);
  const p = page > 1 ? "page/" + page + "/" : "";
  // 强制按日期倒序（最新在上）
  return cat.path + p + "?orderby=date";
}

function parseList(html) {
  const s = String(html || "");
  const out = [];
  const seen = {};

  // 主解析：每个 post-xxx item
  const reItem = /<div[^>]+id=["']post-(\d+)["'][^>]*class=["'][^"']*\bitem\b[^"']*["'][^>]*>([\s\S]*?)(?=<div[^>]+id=["']post-\d+["']|<div class=["']wp-pagenavi|<\/div>\s*<\/div>\s*<\/div>\s*<div id=["']footer|$)/gi;
  let m;
  while ((m = reItem.exec(s))) {
    const postId = m[1];
    const seg = m[2].slice(0, 2800);
    if (seen[postId]) continue;
    seen[postId] = 1;

    let href = "";
    let title = "";

    // clip-link
    let lm =
      seg.match(/<a[^>]+class=["'][^"']*clip-link[^"']*["'][^>]+href=["']([^"']+)["'][^>]*(?:title=["']([^"']*)["'])?/i) ||
      seg.match(/<a[^>]+href=["']([^"']+)["'][^>]+class=["'][^"']*clip-link[^"']*["'][^>]*(?:title=["']([^"']*)["'])?/i);
    if (lm) {
      href = lm[1];
      title = cleanTitle(lm[2] || "");
    }

    // 标题备用
    if (!title) {
      const tm = seg.match(/<h2[^>]*class=["'][^"']*title[^"']*["'][^>]*>\s*<a[^>]+href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/i);
      if (tm) {
        if (!href) href = tm[1];
        title = cleanTitle(tm[2]);
      }
    }

    if (!href) continue;

    let slug = "";
    try {
      const u = host.parseUrl(href);
      const p = ((u && u.path) || "").replace(/\/+$/, "");
      const parts = p.split("/");
      slug = parts[parts.length - 1] || "";
    } catch (e) {
      const mm = href.match(/hentaigasm\.com\/([^\/\?#]+)\/?/i);
      if (mm) slug = mm[1];
    }
    if (!slug || slug === "page" || /^\d+$/.test(slug)) continue;

    let cover = "";
    const im = seg.match(/<img[^>]+(?:src|data-src|data-original)=["']([^"']+)["']/i);
    if (im) cover = abs(im[1]);

    if (!title) title = cleanTitle(slug.replace(/-/g, " "));

    out.push({
      _postId: Number(postId) || 0,
      id: host.dramaId(slug),
      source: host.source,
      sourceId: slug,
      title: title,
      name: title,
      cover: cover,
      coverUrl: cover,
      channelName: "H站精选",
      totalEpisode: 1,
      episodeCount: 1,
    });
  }

  // 宽松备用
  if (out.length === 0) {
    const re2 = /<a[^>]+class=["'][^"']*clip-link[^"']*["'][^>]+href=["'](https?:\/\/(?:www\.)?hentaigasm\.com\/([^"'\/?#]+)\/?)["'][^>]*(?:title=["']([^"']*)["'])?[\s\S]{0,500}?<img[^>]+(?:src|data-src)=["']([^"']+)["']/gi;
    let m2;
    while ((m2 = re2.exec(s))) {
      const slug = m2[2];
      if (!slug || seen[slug] || slug === "page") continue;
      seen[slug] = 1;
      const t = cleanTitle(m2[3] || slug.replace(/-/g, " "));
      out.push({
        _postId: 0,
        id: host.dramaId(slug),
        source: host.source,
        sourceId: slug,
        title: t,
        name: t,
        cover: abs(m2[4]),
        coverUrl: abs(m2[4]),
        channelName: "H站精选",
        totalEpisode: 1,
        episodeCount: 1,
      });
    }
  }

  // 按文章 ID 倒序（越大越新），保证最新在最上面
  out.sort(function (a, b) {
    return (b._postId || 0) - (a._postId || 0);
  });
  for (let i = 0; i < out.length; i++) {
    delete out[i]._postId;
  }
  return out;
}

function hasMoreFromHtml(html, page) {
  const s = String(html || "");
  if (/class=["']nextpostslink["']/i.test(s) || /rel=["']next["']/i.test(s)) return true;
  const re = /\/page\/(\d+)\//gi;
  let m;
  let max = page;
  while ((m = re.exec(s))) {
    const n = Number(m[1]);
    if (n > max) max = n;
  }
  return max > page;
}

function validCategory(category) {
  if (!category) return true;
  const id = String(category);
  for (let i = 0; i < CATS.length; i++) {
    if (CATS[i].id === id) return true;
  }
  return false;
}

function categories() {
  return CATS.map(function (c) {
    return { id: c.id, name: c.name };
  });
}

function catalogPage(page, category) {
  const p = Math.max(1, Number(page) || 1);
  const catId = category || "new";
  const path = listUrl(catId, p);
  const html = getHtml(path, BASE + "/");
  const items = parseList(html);
  const more = hasMoreFromHtml(html, p) && items.length > 0;
  return { items: items, hasMore: more };
}

function search(page, query) {
  const p = Math.max(1, Number(page) || 1);
  const q = String(query || "").trim();
  if (!q) return { items: [], hasMore: false };
  let path = "/?s=" + encodeURIComponent(q);
  if (p > 1) path = "/page/" + p + "/?s=" + encodeURIComponent(q);
  const html = getHtml(path, BASE + "/");
  const items = parseList(html);
  const more = hasMoreFromHtml(html, p) && items.length > 0;
  return { items: items, hasMore: more };
}

function detail(sourceId) {
  const slug = String(sourceId || "")
    .replace(/^\/+|\/+$/g, "")
    .replace(/\.html$/i, "");
  if (!slug) throw new Error("无效的 sourceId");

  const pageUrl = BASE + "/" + slug + "/";
  const html = getHtml("/" + slug + "/", BASE + "/");

  let title = "";
  const tM =
    html.match(/<h1[^>]*class=["'][^"']*entry-title[^"']*["'][^>]*>([\s\S]*?)<\/h1>/i) ||
    html.match(/property=["']og:title["'][^>]+content=["']([^"']+)["']/i) ||
    html.match(/<title>([^<]+?)\s*(?:New Hentai|Hentaigasm|–)/i);
  if (tM) title = cleanTitle(tM[1]);
  if (!title) title = cleanTitle(slug.replace(/-/g, " "));

  let cover = "";
  const cM =
    html.match(/property=["']og:image["'][^>]+content=["']([^"']+)["']/i) ||
    html.match(/jwplayer\([^)]+\)\.setup\s*\(\s*\{[\s\S]{0,800}?image:\s*["']([^"']+)["']/i) ||
    html.match(/<img[^>]+class=["'][^"']*wp-post-image[^"']*["'][^>]+src=["']([^"']+)["']/i);
  if (cM) cover = abs(cM[1]);

  let desc = "";
  const dM = html.match(/<div[^>]+class=["'][^"']*entry-content[^"']*["'][^>]*>([\s\S]*?)<\/div>/i);
  if (dM) desc = unesc(dM[1]).slice(0, 600);

  // 单集内容，固定 1 集
  const chapters = [
    {
      id: host.chapterId(slug, "1"),
      source: host.source,
      title: "正片",
      name: "正片",
      currentEpisode: 1,
      episode: 1,
      // 把 slug 带给 resolveMedia
      videoUrl: slug,
      referer: pageUrl,
      pageUrl: pageUrl,
    },
  ];

  return {
    drama: {
      id: host.dramaId(slug),
      source: host.source,
      sourceId: slug,
      title: title,
      name: title,
      cover: cover,
      coverUrl: cover,
      intro: desc,
      desc: desc,
      channelName: "H站精选",
      totalEpisode: 1,
      episodeCount: 1,
    },
    chapters: chapters,
  };
}

function extractPlayUrl(html) {
  const s = String(html || "");

  // 1. <video> / <source src="...mp4">
  let m = s.match(/<source[^>]+src=["'](https?:\/\/[^"'\s>]+\.mp4[^"'\s>]*)["']/i);
  if (m && m[1]) return m[1].replace(/&amp;/g, "&");

  // 2. jwplayer setup 里的 file（可能带空格）
  m = s.match(/jwplayer\([^)]+\)\.setup\s*\(\s*\{[\s\S]{0,1500}?file:\s*["']([^"']+\.mp4[^"']*)["']/i);
  if (m && m[1]) {
    let u = m[1].replace(/&amp;/g, "&");
    // 对路径中的空格做编码
    try {
      const parsed = host.parseUrl(u);
      if (parsed && parsed.path && /\s/.test(parsed.path)) {
        const segs = parsed.path.split("/");
        for (let i = 0; i < segs.length; i++) {
          if (/\s/.test(segs[i])) segs[i] = encodeURIComponent(segs[i]);
        }
        u = (parsed.scheme || "https") + "://" + parsed.host + segs.join("/");
      }
    } catch (e) {
      u = u.replace(/ /g, "%20");
    }
    return u;
  }

  // 3. 页面里出现的任意 mp4
  m = s.match(/(https?:\/\/[^"'<>\s]+\.mp4[^"'<>\s]*)/i);
  if (m) return m[1].replace(/&amp;/g, "&");

  return "";
}

function sourceIdFromTask(task) {
  // 与潮流AV模块保持一致：优先 dramaId，其次 chapter.videoUrl
  const prefix = host.source + ":";
  let id = "";
  if (task && task.dramaId && String(task.dramaId).indexOf(prefix) === 0) {
    id = String(task.dramaId).slice(prefix.length).trim();
  }
  if (!id && task && task.chapter && task.chapter.videoUrl) {
    id = String(task.chapter.videoUrl).trim();
  }
  if (!id && task && task.chapter && task.chapter.pageUrl) {
    try {
      const u = host.parseUrl(task.chapter.pageUrl);
      const p = ((u && u.path) || "").replace(/\/+$/, "");
      const parts = p.split("/");
      id = parts[parts.length - 1] || "";
    } catch (e) {}
  }
  if (!id && task && task.sourceId) {
    id = String(task.sourceId).trim();
  }
  return String(id || "")
    .replace(/^\/+|\/+$/g, "")
    .replace(/\.html$/i, "");
}

function resolveMedia(task) {
  const slug = sourceIdFromTask(task);
  if (!slug) {
    throw new Error("播放信息无效，请返回详情页重试");
  }

  const pageUrl = BASE + "/" + slug + "/";
  const html = getHtml("/" + slug + "/", pageUrl);
  const url = extractPlayUrl(html);

  if (!url || !/^https?:\/\//i.test(url)) {
    throw new Error("未找到播放地址（页面可能已变更）");
  }

  return host.prepareWebMedia(
    {
      url: url,
      referer: BASE + "/",
    },
    "H站精选"
  );
}

module.exports = {
  validCategory: validCategory,
  categories: categories,
  catalogPage: catalogPage,
  search: search,
  detail: detail,
  resolveMedia: resolveMedia,
};
